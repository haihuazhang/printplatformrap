sap.ui.require(
    [
        'sap/fe/test/JourneyRunner',
        'zzadsconfig/test/integration/FirstJourney',
		'zzadsconfig/test/integration/pages/TemplateList',
		'zzadsconfig/test/integration/pages/TemplateObjectPage'
    ],
    function(JourneyRunner, opaJourney, TemplateList, TemplateObjectPage) {
        'use strict';
        var JourneyRunner = new JourneyRunner({
            // start index.html in web folder
            launchUrl: sap.ui.require.toUrl('zzadsconfig') + '/index.html'
        });

       
        JourneyRunner.run(
            {
                pages: { 
					onTheTemplateList: TemplateList,
					onTheTemplateObjectPage: TemplateObjectPage
                }
            },
            opaJourney.run
        );
    }
);