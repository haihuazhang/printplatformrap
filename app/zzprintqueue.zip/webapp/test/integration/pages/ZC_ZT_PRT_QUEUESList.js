sap.ui.define(['sap/fe/test/ListReport'], function(ListReport) {
    'use strict';

    var CustomPageDefinitions = {
        actions: {},
        assertions: {}
    };

    return new ListReport(
        {
            appId: 'zzprintqueue',
            componentId: 'ZC_ZT_PRT_QUEUESList',
            contextPath: '/ZC_ZT_PRT_QUEUES'
        },
        CustomPageDefinitions
    );
});