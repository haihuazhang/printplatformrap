sap.ui.require(
    [
        'sap/fe/test/JourneyRunner',
        'zzprintqueue/test/integration/FirstJourney',
		'zzprintqueue/test/integration/pages/ZC_ZT_PRT_QUEUESList',
		'zzprintqueue/test/integration/pages/ZC_ZT_PRT_QUEUESObjectPage'
    ],
    function(JourneyRunner, opaJourney, ZC_ZT_PRT_QUEUESList, ZC_ZT_PRT_QUEUESObjectPage) {
        'use strict';
        var JourneyRunner = new JourneyRunner({
            // start index.html in web folder
            launchUrl: sap.ui.require.toUrl('zzprintqueue') + '/index.html'
        });

       
        JourneyRunner.run(
            {
                pages: { 
					onTheZC_ZT_PRT_QUEUESList: ZC_ZT_PRT_QUEUESList,
					onTheZC_ZT_PRT_QUEUESObjectPage: ZC_ZT_PRT_QUEUESObjectPage
                }
            },
            opaJourney.run
        );
    }
);